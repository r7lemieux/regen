package org.codehaus.groovy.grails.plugins.regen.error;

import java.lang.reflect.InvocationTargetException;

/**
 * Created by IntelliJ IDEA.
 * User: Richard Lemieux
 * Date: Jun 19, 2010
 * Time: 3:17:38 AM
 */
public class GenerationException extends Exception {

  public GenerationException(String message) {
    super(message);
  }
}
