package org.codehaus.groovy.grails.plugins.regen;

/**
 * Created by IntelliJ IDEA.
 * User: Richard Lemieux
 * Date: May 31, 2010
 * Time: 2:43:28 PM
 */
public interface Nameable {

  public String getName();

  public void setName(String name);

}
